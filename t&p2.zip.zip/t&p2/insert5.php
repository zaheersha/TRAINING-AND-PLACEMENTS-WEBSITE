<?php
session_start();
$con = mysqli_connect("localhost","root","","basic");

if(isset($_POST['submit']))
{
    $brandlist = $_POST['brandslist'];
    foreach($brandlist as $branditems)
    {
        // echo $branditems."<br>";
        $arraydata = explode("-",$branditems);
       // print_r($arraydata);

        $query = "INSERT INTO round4 (rollnumber,stdname,branch,companyreg,date) VALUES ('$arraydata[0]','$arraydata[1]','$arraydata[2]','$arraydata[3]','$arraydata[4]')";
        $query_run = mysqli_query($con, $query);
    }
  
    if($query_run)
    {
        $_SESSION['status'] = "Inserted Successfully";
        header("Location: index5.php");
    }
    else
    {
        $_SESSION['status'] = "Not Inserted";
        header("Location: index5.php");
    }
}
?>