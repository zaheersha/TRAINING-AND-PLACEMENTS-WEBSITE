<!DOCTYPE html>
<html lang="en">
<head>
	<title>Store Data</title>
</head> 
<body>
	<center>
		<h1>students data</h1>
		<form action="insert.php" method="post">
			
<p>
			<label for="rollno">rollno:</label>
			<input type="text" name="rollno" id="rollno">
			</p>

			
<p>
			<label for="stdname">name:</label>
			<input type="text" name="stdname" id="stdname">
			</p>

			
<p>
			<label for="branch">branch:</label>
			<input type="text" name="branch" id="branch">
			</p>

			
<p>
			<label for="company">company:</label>
			<input type="text" name="company" id="company">
			</p>

			
<p>
			<label for="date">date:</label>
			<input type="text" name="date" id="date">
			</p>

			<input type="submit" value="Submit">
		</form>
	</center>
</body>
</html>
